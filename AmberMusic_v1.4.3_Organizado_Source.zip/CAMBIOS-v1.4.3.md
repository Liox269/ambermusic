# AmberMusic 1.4.3 Organizado

- Acceso a Ajustes directamente con engranaje en Biblioteca.
- Sección Duplicados dentro de Ajustes; permite Analizar, Ocultar copias extra y Mostrar todas.
- Eliminadas de la UI las opciones Exportar/Importar; el código de respaldo se conserva internamente.
- 4 nuevos temas: Aurora, Índigo, Cobre, Menta.
- Selector de carpetas de MediaStore permanece en Ajustes. Music/ continúa incluida de forma automática por diseño; no es todavía selección de cualquier carpeta del almacenamiento usando SAF.
- Motor Media3, efectos blur y Room no modificados.

**Compilación Android no verificada en este entorno.**
