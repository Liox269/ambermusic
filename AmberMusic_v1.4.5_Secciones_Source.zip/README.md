# AmberMusic v1.4.5 — Secciones

Integra el buscador desplegable de v1.4.4 y reorganiza Ajustes de v1.4.3 en pantallas independientes: Biblioteca, Duplicados, Apariencia, Inmersión visual y Audio. No modifica Room, Media3 ni el motor de blur.

Compilar con `gradle :app:assembleDebug`. ZIP de código fuente, no APK.
