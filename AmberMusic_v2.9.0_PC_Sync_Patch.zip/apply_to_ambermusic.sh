#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-.}"
DO_PUSH="${2:-}"

if [ "$REPO_DIR" = "--push" ]; then
  REPO_DIR="."
  DO_PUSH="--push"
fi

if [ ! -d "$REPO_DIR/android/app/src/main/java/dev/liox/ambermusic" ]; then
  echo "Error: ejecuta este script pasando la ruta de tu repositorio local ambermusic."
  echo "Ejemplo: ./apply_to_ambermusic.sh ~/ruta/a/ambermusic --push"
  exit 1
fi

echo "==> Copiando archivos nuevos y actualizados..."
cp -rv "$SCRIPT_DIR/files/." "$REPO_DIR/"

echo "==> Parchando MusicViewModel.kt y ExtrasScreen.kt..."
python3 - "$REPO_DIR" << 'PYEOF'
import sys, os, re

repo = sys.argv[1]

# --- Patch MusicViewModel.kt ---
vm_path = os.path.join(repo, "android/app/src/main/java/dev/liox/ambermusic/viewmodel/MusicViewModel.kt")
with open(vm_path, "r", encoding="utf-8") as f:
    vm = f.read()

if "UrlMusicDownloader" not in vm:
    vm = vm.replace(
        "import dev.liox.ambermusic.artwork.ArtworkRepository",
        "import dev.liox.ambermusic.artwork.ArtworkRepository\n"
        "import dev.liox.ambermusic.artwork.HdCoverCandidate\n"
        "import dev.liox.ambermusic.artwork.HdCoverSearcher\n"
        "import dev.liox.ambermusic.download.DownloadAudioFormat\n"
        "import dev.liox.ambermusic.download.UrlMusicDownloader\n"
        "import kotlinx.coroutines.Job"
    )
    vm = vm.replace(
        "private val profiles: ProfileStore\n) : ViewModel() {",
        "private val profiles: ProfileStore,\n    private val downloader: UrlMusicDownloader\n) : ViewModel() {"
    )
    extra_methods = '''
    private val _urlDownloading = MutableStateFlow(false)
    val urlDownloading: StateFlow<Boolean> = _urlDownloading
    private val _urlDownloadProgress = MutableStateFlow(0f)
    val urlDownloadProgress: StateFlow<Float> = _urlDownloadProgress
    private val _urlDownloadStatus = MutableStateFlow<String?>(null)
    val urlDownloadStatus: StateFlow<String?> = _urlDownloadStatus

    private val _bulkSyncRunning = MutableStateFlow(false)
    val bulkSyncRunning: StateFlow<Boolean> = _bulkSyncRunning
    private val _bulkSyncProgress = MutableStateFlow(0f)
    val bulkSyncProgress: StateFlow<Float> = _bulkSyncProgress
    private val _bulkSyncStatus = MutableStateFlow<String?>(null)
    val bulkSyncStatus: StateFlow<String?> = _bulkSyncStatus
    private var bulkSyncJob: Job? = null

    private val _hdCoverCandidates = MutableStateFlow<List<HdCoverCandidate>>(emptyList())
    val hdCoverCandidates: StateFlow<List<HdCoverCandidate>> = _hdCoverCandidates
    private val _hdCoverSearching = MutableStateFlow(false)
    val hdCoverSearching: StateFlow<Boolean> = _hdCoverSearching

    fun downloadFromUrl(input: String, format: DownloadAudioFormat) {
        if (_urlDownloading.value) return
        viewModelScope.launch {
            _urlDownloading.value = true
            _urlDownloadProgress.value = 0.02f
            _urlDownloadStatus.value = "Preparando descarga…"
            try {
                val res = downloader.download(input, format) { progress, status ->
                    _urlDownloadProgress.value = progress
                    _urlDownloadStatus.value = status
                }
                _urlDownloadStatus.value = "Escaneando biblioteca y buscando portada HD + letra…"
                withContext(Dispatchers.IO) { scanner.scan() }
                val match = libraryUiState.value.songs.firstOrNull {
                    it.displayName.equals(res.displayName, ignoreCase = true) ||
                        it.title.contains(res.title, ignoreCase = true)
                }
                if (match != null) {
                    runCatching { artwork.fetchAndSaveHdCover(match, overwriteCustom = true) }
                    val gotLyrics = runCatching {
                        lyrics.fetchFromLrclib(match.id, match.title, match.artistDisplay, match.albumTitle, match.durationMs)
                    }.getOrDefault(false)
                    if (gotLyrics) lyricsRevision.value += 1
                }
                _urlDownloadProgress.value = 1f
                _urlDownloadStatus.value = "Listo: ${res.title} (${res.format.label})"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _urlDownloadStatus.value = "Error: ${e.localizedMessage ?: "no se pudo descargar"}"
            } finally {
                _urlDownloading.value = false
            }
        }
    }

    fun syncAllCoversAndLyrics(overwriteExistingCovers: Boolean) {
        if (_bulkSyncRunning.value) return
        val songs = libraryUiState.value.songs
        if (songs.isEmpty()) return
        bulkSyncJob = viewModelScope.launch(Dispatchers.IO) {
            _bulkSyncRunning.value = true
            _bulkSyncProgress.value = 0f
            var coversOk = 0
            var lyricsOk = 0
            try {
                songs.forEachIndexed { idx, song ->
                    _bulkSyncStatus.value = "Procesando ${idx + 1}/${songs.size}: ${song.title}"
                    if (runCatching { artwork.fetchAndSaveHdCover(song, overwriteExistingCovers) }.getOrDefault(false)) {
                        coversOk++
                    }
                    if (!lyrics.hasLyrics(song.id)) {
                        if (runCatching {
                                lyrics.fetchFromLrclib(song.id, song.title, song.artistDisplay, song.albumTitle, song.durationMs)
                            }.getOrDefault(false)) {
                            lyricsOk++
                        }
                    }
                    _bulkSyncProgress.value = (idx + 1).toFloat() / songs.size.toFloat()
                }
                if (lyricsOk > 0) lyricsRevision.value += 1
                _bulkSyncStatus.value = "Completado · Portadas HD: $coversOk · Letras: $lyricsOk"
            } catch (e: CancellationException) {
                _bulkSyncStatus.value = "Cancelado · Portadas HD: $coversOk · Letras: $lyricsOk"
                throw e
            } finally {
                _bulkSyncRunning.value = false
            }
        }
    }

    fun cancelBulkSync() {
        bulkSyncJob?.cancel()
        bulkSyncJob = null
    }

    fun searchHdCovers(query: String) {
        viewModelScope.launch {
            _hdCoverSearching.value = true
            try {
                _hdCoverCandidates.value = HdCoverSearcher.search(query)
            } finally {
                _hdCoverSearching.value = false
            }
        }
    }

    fun applyHdCoverToCurrent(candidate: HdCoverCandidate, onDone: (String) -> Unit) {
        val song = playerUiState.value.song
        if (song == null) {
            onDone("Reproduce una canción primero para aplicarle la portada")
            return
        }
        viewModelScope.launch {
            val ok = runCatching {
                val bytes = HdCoverSearcher.downloadBytes(candidate.hdUrl) ?: error("No se pudo descargar la imagen")
                artwork.setCustomBytes(song.id, bytes)
                true
            }.getOrDefault(false)
            onDone(if (ok) "Portada HD aplicada desde ${candidate.source}" else "No se pudo aplicar la portada")
        }
    }
'''
    last_brace = vm.rfind("}")
    vm = vm[:last_brace] + extra_methods + "\n}\n"
    with open(vm_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(vm)
    print("  [OK] MusicViewModel.kt actualizado")
else:
    print("  [SKIP] MusicViewModel.kt ya estaba parchado")

# --- Patch ExtrasScreen.kt ---
ex_path = os.path.join(repo, "android/app/src/main/java/dev/liox/ambermusic/ui/ExtrasScreen.kt")
with open(ex_path, "r", encoding="utf-8") as f:
    ex = f.read()

if "PcToolsPanel(" not in ex:
    ex = ex.replace("if (tab in 0..3)", "if (tab in 0..3 || tab == 16)")
    ex = ex.replace(
        'listOf("Playlists", "Estadísticas", "Inteligentes", "Duplicados").forEachIndexed { index, label ->',
        'listOf(0 to "Playlists", 1 to "Estadísticas", 2 to "Inteligentes", 3 to "Duplicados", 16 to "Descargas y HD").forEach { (index, label) ->'
    )
    # Fallback if exact string had slight formatting difference
    if "Descargas y HD" not in ex:
        ex = re.sub(
            r'listOf\(\s*"Playlists"\s*,\s*"Estadísticas"\s*,\s*"Inteligentes"\s*,\s*"Duplicados"\s*\)\.forEachIndexed\s*\{\s*index\s*,\s*label\s*->',
            'listOf(0 to "Playlists", 1 to "Estadísticas", 2 to "Inteligentes", 3 to "Duplicados", 16 to "Descargas y HD").forEach { (index, label) ->',
            ex
        )
    ex = ex.replace(
        "when (tab) {",
        "when (tab) {\n            16 -> PcToolsPanel(library = library, viewModel = viewModel)"
    )
    with open(ex_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(ex)
    print("  [OK] ExtrasScreen.kt actualizado")
else:
    print("  [SKIP] ExtrasScreen.kt ya estaba parchado")
PYEOF

echo "==> Parche aplicado correctamente."
if [ "$DO_PUSH" = "--push" ]; then
  cd "$REPO_DIR"
  git checkout main
  git pull --ff-only origin main || true
  git add android/ .github/workflows/build-android-current.yml
  git commit -m "feat(android): port PC HD covers, multi-source lyrics, URL downloads (FLAC/MP3/OPUS/M4A) and bulk library sync"
  git push origin main
  echo "==> Cambios subidos a main. GitHub Actions comenzará a compilar AmberMusic-v2.9.0-debug.apk automáticamente."
else
  echo "Para subir a main y disparar GitHub Actions automáticamente, ejecuta:"
  echo "  cd \"$REPO_DIR\" && git add -A && git commit -m \"feat(android): port PC HD covers, multi-source lyrics and URL downloads\" && git push origin main"
fi
